export const HORSE_NAMES = [
  'Afitap Abla',
  'Biletçi Kız',
  'Çapraz Ateş',
  'Diyarbekir',
  'Kuzgun Bey',
  'Tay Fark',
  'Tarzan',
  'Domates Güzeli',
  'Yağmur 5',
  'Karapınar Aslanı',
  'Mavidalga',
  'Big Bang',
  'Ginny Weasley',
  'Cash is King',
  'Good Curry',
  'Database',
  'Splendid',
  'Rainbow Storm',
  'Masterpiece',
  'Hidden Lake'
]


//! Atın hızını belirlemek için kullanılan sabit değer bu değeri değiştirerek atların hızını değiştirebilirsiniz
export const SPEED_FACTOR = 1.15
